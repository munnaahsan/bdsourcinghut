<?php $__env->startSection('seo_title',$page->seo_title ?: $page->title); ?>
<?php $__env->startSection('seo_description',$page->seo_description ?: $page->excerpt); ?>
<?php $__env->startSection('og_image',$page->heroImage?->url ?? asset('images/hero/hero-main.jpg')); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $page->visibleSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->make('frontend.partials.section',['section'=>$section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\BD Sourching Hut\bd-sourcing-hut\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>