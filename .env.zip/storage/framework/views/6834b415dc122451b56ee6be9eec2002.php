<!doctype html>
<html lang="en">

<?php
    // Provide safe defaults for shared layout data.
    // Existing values supplied by controllers are preserved.
    $site = $site ?? [];
    $theme = $theme ?? [];

    $logoMedia = $logoMedia ?? null;
    $faviconMedia = $faviconMedia ?? null;

    $mainMenu = $mainMenu ?? null;
    $footerMenu = $footerMenu ?? null;
?>


<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="<?php echo e($theme['background'] ?? '#10111A'); ?>">
  <?php
    $seoTitle=trim($__env->yieldContent('seo_title', $site['default_seo_title'] ?? 'BD SOURCING HUT'));
    $seoDescription=trim($__env->yieldContent('seo_description', $site['default_seo_description'] ?? ''));
    $seoRobots=trim($__env->yieldContent('robots','index,follow'));
    $canonicalUrl=trim($__env->yieldContent('canonical',url()->current()));
    $ogImage=trim($__env->yieldContent('og_image',asset('images/hero/hero-main.jpg')));
  ?>
  <title><?php echo e($seoTitle); ?></title>
  <meta name="description" content="<?php echo e($seoDescription); ?>">
  <meta name="robots" content="<?php echo e($seoRobots); ?>">
  <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
  <meta property="og:type" content="website"><meta property="og:title" content="<?php echo e($seoTitle); ?>"><meta property="og:description" content="<?php echo e($seoDescription); ?>">
  <meta property="og:image" content="<?php echo e($ogImage); ?>">
  <?php if($faviconMedia): ?><link rel="icon" href="<?php echo e($faviconMedia->url); ?>"><?php endif; ?>
  <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&family=DM+Sans:wght@400;500;600;700&family=DM+Serif+Display&family=Inter:wght@400;500;600;700&family=Manrope:wght@400;500;600;700&family=Playfair+Display:wght@400;500;600&display=swap" rel="stylesheet">
  <style>:root{
     --c-primary:<?php echo e($theme['primary'] ?? '#172B68'); ?>;--c-secondary:<?php echo e($theme['secondary'] ?? '#10111A'); ?>;--c-accent:<?php echo e($theme['accent'] ?? '#D9BC83'); ?>;
     --c-bg:<?php echo e($theme['background'] ?? '#10111A'); ?>;--c-surface:<?php echo e($theme['surface'] ?? '#17202D'); ?>;--c-light:<?php echo e($theme['light'] ?? '#F7F2E9'); ?>;
     --c-text:<?php echo e($theme['text'] ?? '#F7F2E9'); ?>;--c-muted:<?php echo e($theme['muted'] ?? '#C9CED8'); ?>;--c-button:<?php echo e($theme['button'] ?? '#D9BC83'); ?>;
     --font-display:'<?php echo e($theme['heading_font'] ?? 'Cormorant Garamond'); ?>',Georgia,serif;
     --font-body:'<?php echo e($theme['body_font'] ?? 'Manrope'); ?>',Arial,sans-serif;--card-radius:<?php echo e($theme['radius'] ?? '12'); ?>px;
     --shadow-strength:<?php echo e(($theme['shadow_intensity'] ?? 50)/100); ?>;--motion-strength:<?php echo e(($theme['animation_intensity'] ?? 75)/100); ?>;
  }</style>
  <link rel="stylesheet" href="<?php echo e(asset('assets/site.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/premium-cursor.css')); ?>?v=1">
  <script defer src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
  <script defer src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/ScrollTrigger.min.js"></script>
  <script defer src="<?php echo e(asset('assets/site.js')); ?>"></script>
  <script defer src="<?php echo e(asset('assets/premium-cursor.js')); ?>?v=1"></script>
  <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>
<div class="site-loader" aria-hidden="true"><span>BD<span class="loader-line"></span></span></div>
<header class="site-header" id="site-header">
 <div class="header-inner">
  <a href="<?php echo e(route('home')); ?>" class="brand" aria-label="BD SOURCING HUT home">
    <?php if($logoMedia): ?><img src="<?php echo e($logoMedia->url); ?>" alt="<?php echo e($site['site_name'] ?? 'BD SOURCING HUT'); ?> logo"><?php else: ?><span class="brand-symbol">BD</span><span class="brand-word">SOURCING<br>HUT</span><?php endif; ?>
  </a>
  <nav class="desktop-nav" aria-label="Primary navigation">
  <?php $__currentLoopData = $mainMenu?->items ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="nav-item <?php if($nav->children->isNotEmpty()): ?> has-dropdown <?php endif; ?>">
    <a class="nav-link" href="<?php echo e($nav->url); ?>" <?php if($nav->target==='_blank'): ?>target="_blank" rel="noopener noreferrer"<?php endif; ?>><?php echo e($nav->label); ?></a>
    <?php if($nav->children->isNotEmpty()): ?>
     <button class="nav-toggle" aria-label="Open <?php echo e($nav->label); ?> submenu" aria-expanded="false" type="button"><span aria-hidden="true">⌄</span></button>
     <div class="submenu" role="group" aria-label="<?php echo e($nav->label); ?> submenu">
      <span class="submenu-kicker">EXPLORE <?php echo e($nav->label); ?></span>
      <?php $__currentLoopData = $nav->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e($child->url); ?>" <?php if($child->target==='_blank'): ?>target="_blank" rel="noopener noreferrer"<?php endif; ?>><?php echo e($child->label); ?><span aria-hidden="true">↗</span></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
    <?php endif; ?>
   </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </nav>
  <div class="header-actions"><a class="btn btn-gold btn-small" href="<?php echo e($site['header_cta_url'] ?? '/contact'); ?>"><?php echo e($site['header_cta_label'] ?? 'START A PROJECT'); ?> <span>↗</span></a></div>
  <button class="mobile-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-nav"><span></span><span></span></button>
 </div>
</header>
<div class="mobile-menu" id="mobile-nav" aria-hidden="true"><div class="mobile-menu-inside">
 <?php $__currentLoopData = $mainMenu?->items ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="mobile-nav-block"><a class="mobile-nav-heading" href="<?php echo e($nav->url); ?>"><?php echo e($nav->label); ?> <span>↗</span></a>
   <?php if($nav->children->isNotEmpty()): ?><div class="mobile-subnav"><?php $__currentLoopData = $nav->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e($child->url); ?>"><?php echo e($child->label); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
  </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <a class="btn btn-gold" href="<?php echo e($site['header_cta_url'] ?? '/contact'); ?>"><?php echo e($site['header_cta_label'] ?? 'START A PROJECT'); ?> ↗</a>
 </div></div>
<main id="main"><?php echo $__env->yieldContent('content'); ?></main>
<footer class="footer" id="footer"><div class="footer-top">
  <div><span class="eyebrow gold">BD SOURCING HUT · BANGLADESH</span><h2>LET'S MAKE<br><em>IT HAPPEN.</em></h2><p><?php echo e($site['footer_statement'] ?? ''); ?></p><a class="text-link" href="<?php echo e(route('contact')); ?>">START A CONVERSATION <span>↗</span></a></div>
  <div class="footer-details"><span class="eyebrow">EXPLORE</span><nav aria-label="Footer navigation"><?php $__currentLoopData = $footerMenu?->items ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e($nav->url); ?>"><?php echo e($nav->label); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></nav></div>
  <div class="footer-details"><span class="eyebrow">CONNECT</span>
    <?php if(!empty($site['contact_email'])): ?><a href="mailto:<?php echo e($site['contact_email']); ?>"><?php echo e($site['contact_email']); ?></a><?php endif; ?>
    <?php if(!empty($site['contact_phone'])): ?><a href="tel:<?php echo e($site['contact_phone']); ?>"><?php echo e($site['contact_phone']); ?></a><?php endif; ?>
    <?php if(!empty($site['contact_address'])): ?><p><?php echo e($site['contact_address']); ?></p><?php endif; ?>
    <div class="footer-social"><?php $__currentLoopData = ['instagram'=>'Instagram','linkedin'=>'LinkedIn','facebook'=>'Facebook']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(!empty($site['social_'.$key])): ?><a href="<?php echo e($site['social_'.$key]); ?>" target="_blank" rel="noopener noreferrer"><?php echo e($label); ?> ↗</a><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
  </div>
 </div><div class="footer-bottom"><span>© <?php echo e(date('Y')); ?> <?php echo e($site['footer_copyright'] ?? 'BD SOURCING HUT'); ?></span><span>GLOBAL APPAREL SOURCING / BANGLADESH</span><a href="#main">BACK TO TOP ↑</a></div>
</footer>
</body></html>
<?php /**PATH C:\laragon\www\BD Sourching Hut\bd-sourcing-hut\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>